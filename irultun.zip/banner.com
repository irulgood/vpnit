html
<font color="#FFD700">✨ Terima Kasih Telah Menggunakan Layanan Kami! ✨</font>

<font color="#00C1FF">Kami sangat menghargai kepercayaan Anda telah memilih dan menggunakan layanan kami.</font>

<font color="#00C1FF">Semoga layanan yang kami berikan dapat memberikan pengalaman terbaik dan memenuhi kebutuhan Anda. 🙏</font>

<font color="#F5FE00">Salam hangat,</font>
<font color="#00FF7F">Tim Admin</font>
